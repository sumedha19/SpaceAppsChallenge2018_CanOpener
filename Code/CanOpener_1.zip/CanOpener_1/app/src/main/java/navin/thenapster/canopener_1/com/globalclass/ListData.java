package navin.thenapster.canopener_1.com.globalclass;

public class ListData {

    int id;
    String item_name;
    boolean status;

    public ListData(int id,String name){
        this.item_name=name;
        this.id=id;
        this.status=false;
    }
    public String getItem_name(){
        return item_name;
    }

    public int getId() {
        return id;
    }

    public boolean isStatus() {
        return status;
    }
    public void setId(int id){
        this.id=id;
    }
    public void setItem_name(String name){
        this.item_name=name;
    }
    public void setStatus(boolean status){
        this.status=status;
    }
    public void check(){
        this.status=true;
    }

}
