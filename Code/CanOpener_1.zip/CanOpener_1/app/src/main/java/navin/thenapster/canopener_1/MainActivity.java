package navin.thenapster.canopener_1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Toast;

import navin.thenapster.canopener_1.com.globalclass.MyGlobalClass;

public class MainActivity extends AppCompatActivity {
    public static Context context;
    CardView card1,card2,card3,card4;


    @Override
    public Context getApplicationContext() {
        return super.getApplicationContext();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context=getApplicationContext();
        card1=(CardView)findViewById(R.id.card1);
        card2=(CardView)findViewById(R.id.card2);
        card3=(CardView)findViewById(R.id.card3);
        card4=(CardView)findViewById(R.id.card4);


        card1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"You clicked" + String.valueOf(R.string.disaster1),Toast.LENGTH_LONG ).show();
                Intent intent =new Intent(MainActivity.this,Mode.class);
                intent.putExtra("DISASTER",R.string.disaster1);

                MyGlobalClass globalvariable= (MyGlobalClass) context;
                globalvariable.setDisasterName("Flood");
                startActivity(intent);
            }
        });

        card2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"You clicked" + String.valueOf(R.string.disaster2)  ,Toast.LENGTH_LONG ).show();
                Intent intent =new Intent(MainActivity.this,Mode.class);
                intent.putExtra("DISASTER",R.string.disaster2);

                MyGlobalClass globalvariable= (MyGlobalClass) context;
                globalvariable.setDisasterName("EarthQuakes");

                startActivity(intent);
            }
        });
        card3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"You clicked" + String.valueOf(R.string.disaster3 ),Toast.LENGTH_LONG ).show();
                Intent intent =new Intent(MainActivity.this,Mode.class);
                intent.putExtra("DISASTER",R.string.disaster3);

                MyGlobalClass globalvariable= (MyGlobalClass) context;
                globalvariable.setDisasterName("Cyclones");

                startActivity(intent);
            }
        });
        card4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"You clicked" + String.valueOf(R.string.disaster4),Toast.LENGTH_LONG ).show();
                Intent intent =new Intent(MainActivity.this,Mode.class);
                intent.putExtra("DISASTER",R.string.disaster4);

                MyGlobalClass globalvariable= (MyGlobalClass) context;
                globalvariable.setDisasterName("Volcano");

                startActivity(intent);
            }
        });

    }

}
