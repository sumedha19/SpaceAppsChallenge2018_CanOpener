package navin.thenapster.canopener_1;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import navin.thenapster.canopener_1.com.globalclass.MyGlobalClass;


public class VirtualBagFragment extends Fragment {

    public String disaster_name =null;

    public static Context context;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState){


//        MyGlobalClass globalVariable =(MyGlobalClass) context;
//        disaster_name = globalVariable.getDisasterName();


        return inflater.inflate(R.layout.fragment_virtual_bag,container,false);



    }

}
