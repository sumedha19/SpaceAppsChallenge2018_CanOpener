package navin.thenapster.canopener_1;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class TutorialFragment extends Fragment {

    ImageView img;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState){
        View view=inflater.inflate(R.layout.fragment_tutorial,null);
        img =(ImageView) view.findViewById(R.id.tutorial);
        return view;
    }

    public void changeDiaster(String disaster_name){
        if(disaster_name=="Flood"){
            img.setImageResource(R.drawable.fd_tutorial);
        }else if(disaster_name=="EarthQuakes"){
            img.setImageResource(R.drawable.eq_tutorial);
        }else if(disaster_name=="Cyclones"){
            img.setImageResource(R.drawable.cy_tutorial);
        }else if(disaster_name=="Volcano"){
            img.setImageResource(R.drawable.vo_tutorial);
        }else{
            img.setImageResource(R.drawable.fd_tutorial);
        }

    }

}
