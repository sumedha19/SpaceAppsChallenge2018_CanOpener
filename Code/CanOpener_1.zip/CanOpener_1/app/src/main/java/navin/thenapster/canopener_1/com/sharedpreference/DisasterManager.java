package navin.thenapster.canopener_1.com.sharedpreference;

import android.content.Context;
import android.content.SharedPreferences;


public class DisasterManager {

    Context context;

    DisasterManager(Context context){
        this.context=context;
    }

    public void saveDetails(String disaster_name){
        SharedPreferences sharedPreferences= context.getSharedPreferences("disasterDetails",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor =sharedPreferences.edit();

        editor.putString("disaster_name",disaster_name);
        editor.commit();
    }

    public String getDisasterName(){
        SharedPreferences sharedPreferences= context.getSharedPreferences("disasterDetails",Context.MODE_PRIVATE);
        return sharedPreferences.getString("disaster_name","");
    }

    public boolean checkDetails(){
        SharedPreferences sharedPreferences= context.getSharedPreferences("disasterDetails",Context.MODE_PRIVATE);
        boolean isNameEmpty = sharedPreferences.getString("disaster_name","").isEmpty();
        return isNameEmpty;
    }


}
