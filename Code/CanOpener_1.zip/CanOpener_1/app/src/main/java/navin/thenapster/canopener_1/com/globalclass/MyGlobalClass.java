package navin.thenapster.canopener_1.com.globalclass;

import android.app.Application;

import java.util.ArrayList;

public class MyGlobalClass extends Application {
    public String disaster_name;
    public ArrayList<ListData> listdata;

    @Override
    public void onCreate(){
        super.onCreate();
    }

    public String getDisasterName(){
        return disaster_name;

    }
    public void setDisasterName(String name){
        disaster_name=name;
    }

    public int addList(String desc){

        int id= listdata.size()+1;
        ListData e= new ListData(id,desc);
        listdata.add(e);

        return listdata.size();

    }


    public ListData[] getList(){
       return listdata.toArray(new ListData[listdata.size()]);
    }

    public boolean removeitem(int id){

        boolean flag= false;
        for (ListData i :listdata ){
            if (i.getId()==id){
                listdata.remove(i);
                flag=true;
                break;
            }
        }

        return flag;
    }

//    public void reorder(ListData i, ListData j){
//
//        for(ListData k : listdata){
//            if(k.getId()==i.getId()){
//                i.setId(j.getId());
//            }else (k.getId()==j.getId()){
//
//            }
//                j.setId(i.getId());
//
//        }
//
//    };

//    public void changeitem(ListData i){
//
//        for (ListData k : listdata){
//            if(k.getId()==i.getId()){
//                listdata.remove(k);
//                listdata.add(listdata.indexOf(k),)
//            }
//        }
//
//    }

}
